// Game Name: 
// Written by: 
// Date: 
//
// Instructions:
//

#include "graphics.h"
#include <string>
#include <random>

using namespace std;

const int BACKGROUND_COLOR = GREEN;
const int TEXT_COLOR = RED;

random_device myEngine;
uniform_real_distribution<double> randomReal(0.0, 1.0);

void welcomeScreen();

int main()
{
	bool keepGoing = true;
	char keyPressed;

	initwindow(1000, 1000, (char*) "Game Name Here", 10, 10);

	welcomeScreen();

	bool playAgain = true;

	//
	// -------- Main "Play Again" loop
	//
	do {


		// 
		// -------- Main "Keep Going" loop
		// 
		keepGoing = true;
		while (keepGoing) {
			delay(100);

			// -------- Check to see if a key has been pressed
			if (kbhit()) {
				keyPressed = getch();

				// KEY: Q or ESC pressed
				if (keyPressed == 'q' || keyPressed == 'Q' || keyPressed == 0x1b) {
					keepGoing = false;
				}
			}

			// -------- Check to see if a mouse was clicked 
			if (ismouseclick(WM_LBUTTONUP)) {
				int mouseX, mouseY;
				getmouseclick(WM_LBUTTONUP, mouseX, mouseY);
			}

		} // end while(keepGoing)

		// Game has ended

		outtextxy(10, 10, (char*) "GAME OVER, Play Again (Y/N)");
		keyPressed = getch();
		if (keyPressed == 'y' || keyPressed == 'Y') {
			welcomeScreen();
		}
		else {
			playAgain = false;
		}

	} while (playAgain == true);  // Main "Play Again" loop

	return 0;
} // end main()


void welcomeScreen() {
	setbkcolor(BACKGROUND_COLOR);
	cleardevice();

	setcolor(TEXT_COLOR);
	settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
	outtextxy(10, 10, (char*) "Press any key to begin");

	getch();
	cleardevice();
}
